<?php

/* Widgets Panel */
FLCustomizer::add_panel( 'widgets', array(
	'title' => _x( 'Widgets', 'Customizer panel title.', 'fl-automator' )
) );