(function($){

	FLBuilder.registerModuleHelper('icon-group', {
		
		rules: {
			size: {
				number: true,
				required: true
			}
		}
	});

})(jQuery);